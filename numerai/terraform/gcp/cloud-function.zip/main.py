import os
import json
from google.cloud import workflows_v1
from google.cloud.workflows import executions_v1beta
from google.cloud.workflows.executions_v1beta import Execution
from google.cloud.workflows.executions_v1beta.types import executions


def run_job(request):
    request_json = request.get_json(silent=True)
    print(request_json)
    trigger_id = request_json["triggerId"]

    project = os.getenv("PROJECT")
    location = os.getenv("LOCATION")
    workflow = os.getenv("WORKFLOW")

    execution_client = executions_v1beta.ExecutionsClient()
    workflows_client = workflows_v1.WorkflowsClient()
    # Construct the fully qualified location path.
    parent = workflows_client.workflow_path(project, location, workflow)

    print(parent)
    argument = {"trigger_id": trigger_id}

    response = execution_client.create_execution(
        request={"parent": parent, "execution": {"argument": json.dumps(argument)}}
    )
    print(f"Created execution: {response.name}")

    # Handle the response
    return "Ok"
