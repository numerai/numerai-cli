import os
from google.cloud import run_v2


def run_job(_):
    # Create a client
    client = run_v2.JobsClient()

    project = os.getenv("PROJECT")
    location = os.getenv("LOCATION")
    job = os.getenv("JOB")

    request = run_v2.RunJobRequest(
        name=f"projects/{project}/locations/{location}/jobs/{job}",
    )

    # Make the request
    client.run_job(request=request)

    print("Model has been triggered")

    # Handle the response
    return "Ok"
