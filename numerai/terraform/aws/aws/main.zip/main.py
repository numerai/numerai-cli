import json
import boto3
import os


def lambda_handler(event, context):
    try:
        print(json.loads(event["body"]))
        trigger_id = json.loads(event["body"])["triggerId"]

        job_definition = os.getenv("JOB_DEFINITION")
        job_queue = os.getenv("JOB_QUEUE")

        client = boto3.client("batch")
        response = client.submit_job(
            jobDefinition=job_definition,
            jobName=f"{job_definition}-{trigger_id}",
            jobQueue=job_queue,
            containerOverrides={
                "environment": [{"name": "TRIGGER_ID", "value": trigger_id}]
            },
        )

        print(response)
        # Handle the response
        return {
            "statusCode": 200,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"Status": "ok"}),
        }

    except Exception as ex:
        print(ex)
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({"Error": str(ex)}),
        }
