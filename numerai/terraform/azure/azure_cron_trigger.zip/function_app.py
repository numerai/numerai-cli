import datetime
import logging
import azure.functions as func
import requests
import os

app = func.FunctionApp()

# https://arminreiter.com/2017/02/azure-functions-time-trigger-cron-cheat-sheet/
if os.environ.get('CRON_EXPRESSION'):
    cron_expression = os.environ.get('CRON_EXPRESSION')
else:
    # Every Sunday, Tuesday, Wednesday, Thursday and Friday at 13:30 UTC
    cron_expression = "0 30 13 * * SUN,TUE,WED,THU,FRI"

@app.schedule(schedule=cron_expression, arg_name="myTimer", run_on_startup=False,
              use_monitor=False)
def TimerTrigger(myTimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    
    # Load Webhook URL from pass into the settings from Terraform
    webhook_url=os.environ.get('WEBHOOK_URL')
    response=requests.post(
    webhook_url,
    timeout=30,
    )
    
    logging.info(f'Response code: {response.status_code}', utc_timestamp)
    logging.info(f'Response details: {response.text}', utc_timestamp)
    
    logging.info('Python timer trigger function ran at %s', utc_timestamp)