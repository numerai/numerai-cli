import azure.functions as func
import azure.durable_functions as df
import logging
from azure.mgmt.containerinstance import ContainerInstanceManagementClient
from azure.identity import DefaultAzureCredential
import os

myApp = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# An HTTP-Triggered Function with a Durable Functions Client binding
@myApp.route(route="orchestrators/{functionName}")
@myApp.durable_client_input(client_name="client")
async def http_start(req: func.HttpRequest, client):
    logging.info('HTTP trigger: received a request')
    function_name = req.route_params.get('functionName')
    instance_id = await client.start_new(function_name)
    response = client.create_check_status_response(req, instance_id)
    return response

# Orchestrator -> to start and track all activities
@myApp.orchestration_trigger(context_name="context")
def start_submission(context):
    result1 = yield context.call_activity("run_container", "")

    return [result1]

# Activity -> put the submission code here
@myApp.activity_trigger(input_name="input")
def run_container(input: str):
    logging.info('Cantainer Run: request received')
    
    client = ContainerInstanceManagementClient(
        credential=DefaultAzureCredential(),
        subscription_id=os.environ["AZURE_SUBSCRIPTION_ID"]) # loaded from .env within azure_trigger_function folder
    # func.HttpResponse(f"This HTTP triggered function executed successfully.",status_code=200)
    
    response = client.container_groups.begin_start(
        resource_group_name=os.environ["AZURE_RESOURCE_GRP_NAME"],
        container_group_name=os.environ["AZURE_CONTAINER_GRP_NAME"],
        ).result()
    logging.info('Cantainer Run: SUCCESSFUL')
    return "Run successful"