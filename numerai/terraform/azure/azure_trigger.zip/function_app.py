import azure.functions as func
import azure.durable_functions as df
import logging
from azure.mgmt.containerinstance import ContainerInstanceManagementClient
from azure.identity import DefaultAzureCredential
import os
#from dotenv import load_dotenv
from azure.mgmt.containerinstance.models import EnvironmentVariable


myApp = df.DFApp(http_auth_level=func.AuthLevel.ANONYMOUS)

# An HTTP-Triggered Function with a Durable Functions Client binding
@myApp.route(route="orchestrators/{functionName}")
@myApp.durable_client_input(client_name="client")
async def http_start(req: func.HttpRequest, client):
    global req_body
    req_body={}
    try:
        req_body = req.get_json()
        logging.info(req_body)
    except ValueError:
        pass
    logging.info('HTTP trigger: received a request')
    function_name = req.route_params.get('functionName')
    instance_id = await client.start_new(function_name)
    response = client.create_check_status_response(req, instance_id)

    # Default response code is 202, need to change to 200 to tell Numerai that the request was successful.
    return func.HttpResponse(f"Container run triggered. Can check the run status at the 'statusQueryGetUri' key of the raw response json. "
                             f"Raw response: {response.get_body()}", status_code=200)

# Orchestrator -> to start and track all activities
# Call "start_submission" to start the submission properly
@myApp.orchestration_trigger(context_name="context")
def start_submission(context):
    result1 = yield context.call_activity("run_container", "")

    return [result1]

# Activity -> put the submission code here
@myApp.activity_trigger(input_name="input")
def run_container(input: str):
    try:
        if req_body.get("triggerId"):
            env_var_trigger_id = EnvironmentVariable(name='TRIGGER_ID', value=req_body['triggerId'])
    except:
        pass
    logging.info('Container Run: request received')
    client = ContainerInstanceManagementClient(
        credential=DefaultAzureCredential(),
        subscription_id=os.environ["AZURE_SUBSCRIPTION_ID"]) # loaded from .env within azure_trigger_function folder
    
    # June 2023: Waiting support from official Azure SDK'environment_variables=[env_var_trigger_id]'
    response = client.container_groups.begin_start(
        resource_group_name=os.environ["AZURE_RESOURCE_GRP_NAME"],
        container_group_name=os.environ["AZURE_CONTAINER_GRP_NAME"],
        ).result()
    logging.info('Container Run: SUCCESSFUL')

    return "Run successful"