# If you're using VS Code, press F5 to debug locally
import azure.functions as func
import logging
from azure.identity import DefaultAzureCredential
from azure.mgmt.containerinstance import ContainerInstanceManagementClient
import os


# Get started by running the following code to create a function using a HTTP trigger.
## Azure docs:https://docs.microsoft.com/en-us/azure/azure-functions/functions-bindings-http-webhook-trigger?tabs=python#example 
## Learn more at aka.ms/pythonprogrammingmodel

#app = func.FunctionApp()
#@app.function_name(name="numerai-trigger")
#@app.route(route='predict',methods=['GET','POST'],auth_level=func.AuthLevel.ANONYMOUS)

# This function will be triggered by a GET or POST request
def main(predict: func.HttpRequest) -> str:
    
    logging.info('Python HTTP trigger function processed a request.')
    
    client = ContainerInstanceManagementClient(
        credential=DefaultAzureCredential(),
        subscription_id=os.environ["AZURE_SUBSCRIPTION_ID"]) # loaded from .env within azure_trigger_function folder
    
    response = client.container_groups.begin_start(
        resource_group_name=os.environ["AZURE_RESOURCE_GRP_NAME"],
        container_group_name=os.environ["AZURE_CONTAINER_GRP_NAME"],
        ).result()
    
    return func.HttpResponse(f"This HTTP triggered function executed successfully.",status_code=200)
